﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities.Enums
{
    public enum MovementType
    {
        Entrada = 1,
        Saida = 2
    }
}
